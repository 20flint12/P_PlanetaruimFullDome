Downloaded from PlanIT 3D at http://www.planit3d.com
PlanIT 3D, and all its contents, is copyrighted unless strictly stated on the associated web page. 
All of the models / meshes available on PlanIT 3D for download may be used royalty-free in your own work 
if you give proper credit to PlanIT 3D (i.e., Models provided by PlanIT3d.com). 
If any of the models / meshes available on PlanIT 3D are to be used commercially, you must contact us for licensing agreements. 
Also, these models / meshes may not be sold individually or included in, or sold as, or provided for free in, a collection of any kind including 
collections available on CD-ROM, BBS, FTP, WWW, IRC or any other electronic transfer methods without prior written permission from PlanIT 3D and
from the authors/artists whom created these models where stated. By using any of PlanIT 3D's models / meshes you and your company explicitly
agree with these terms and conditions. PlanIT 3D makes no warranties, express or implied,
and disclaim any warranty or merchantability or fitness for a particular purpose. Neither PlanIT 3D nor its business partners shall be liable for
any indirect, incidental or consequential damages (including but not limited to lost profits) incurred from the use or inability to use the
models / meshes and software available on PlanIT 3D.

PLEASE ADHERE TO THESE SIMPLE RULES TO KEEP THIS SITE FREE FOR THE WHOLE 3D COMMUNITY.
